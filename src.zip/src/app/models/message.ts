export interface Message {
  status: string;
  percent_complete: number;
  user: string
}
