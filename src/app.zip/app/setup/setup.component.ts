import { Component, OnInit, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'app-setup',
  templateUrl: './setup.component.html',
  styleUrls: ['./setup.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class SetupComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
