import { Component, OnInit, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'app-setup-five',
  templateUrl: './setup-five.component.html',
  styleUrls: ['./setup-five.component.css'],
  encapsulation: ViewEncapsulation.None

})
export class SetupFiveComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
