import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-setup-two',
  templateUrl: './setup-two.component.html',
  styleUrls: ['./setup-two.component.css']
})
export class SetupTwoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
